#include <Geode/Geode.hpp>
#include <Geode/modify/MenuLayer.hpp>

using namespace geode::prelude;

class $modify(HiiiiMenuLayer, MenuLayer) {
    bool init() {
        if (!MenuLayer::init()) return false;

        auto menu = CCMenu::create();
        menu->setPosition({60.f, 60.f});

        auto button = CCMenuItemSpriteExtra::create(
            ButtonSprite::create("Level Editor", 90, true, "bigFont.fnt", "GJ_button_01.png", 25, 1.f),
            this,
            menu_selector(HiiiiMenuLayer::onEditor)
        );

        menu->addChild(button);
        this->addChild(menu, 10);
        return true;
    }

    void onEditor(CCObject*) {
        FLAlertLayer::create(
            "Hiiii Main Level Editor",
            "Main-level editor loaded! Use this mod as the base for custom main-level replacement data.",
            "OK"
        )->show();
    }
};

# Changelog

## v1.0.0
- Initial project.
- Added Android 2.2081 target.
